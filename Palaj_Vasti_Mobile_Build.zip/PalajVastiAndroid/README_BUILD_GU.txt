PALAJ VASTI - Android Studio project

આ પ્રોજેક્ટમાં ગુજરાતી વસ્તી વેબ એપ Android WebView wrapperમાં સામેલ છે.

APK બનાવવા:
1. Android Studio (નવું વર્ઝન) ખોલો.
2. File > Open કરીને આ ફોલ્ડર પસંદ કરો.
3. Gradle sync પૂર્ણ થવા દો અને Android SDK Platform 35 ઇન્સ્ટોલ કરો.
4. Build > Build Bundle(s) / APK(s) > Build APK(s) પસંદ કરો.
5. APK અહીં મળશે: app/build/outputs/apk/debug/app-debug.apk

નોંધ: આ source project છે, પહેલેથી compile થયેલી APK નથી. આ runtimeમાં Android SDK/Gradle ઉપલબ્ધ ન હોવાથી અહીં APK compile કરી શકાતી નથી.
મૂળ વસ્તી રેકોર્ડ app/src/main/assets/data.jsonમાં છે. ઘર નંબર મૂળ Excelમાં ન હોવાથી પરિવાર/ઘર નંબર એપમાં ઉમેરવાનો રહેશે.

માત્ર મોબાઇલથી APK બનાવવા (GitHub Actions):
1. ZIP ને ફોનમાં Extract કરો.
2. github.com પર એકાઉન્ટ બનાવી Sign in કરો.
3. New repository બનાવી તેનું નામ PalajVasti રાખો.
4. Add file > Upload files માં Extract કરેલા PalajVastiAndroid ફોલ્ડરની અંદરની બધી ફાઇલો/ફોલ્ડર અપલોડ કરો (ખાસ કરીને .github ફોલ્ડર પણ).
5. Commit changes કરો.
6. Repository > Actions > Build PALAJ VASTI APK > Run workflow ચલાવો.
7. Build પૂરું થયા પછી workflow run ખોલો; Artifacts માં PALAJ-VASTI-APK ડાઉનલોડ કરો.
8. ZIP ખોલીને app-debug.apk પર ટૅપ કરીને Install કરો.
